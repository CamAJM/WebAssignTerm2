var mongoose = require('mongoose');
var Schema = mongoose.Schema; 
var menuItemSchema = new Schema({
	_id: Number,
	title: { type: String, uppercase: true },
	price: Number 
	
});

module.exports = mongoose.model('MenuItem', menuItemSchema); 
// Finds the collection menuitem. Mongo adds an s to the collection name here. So while "menuitem" is entered, Mongo looks for "menuitems".
