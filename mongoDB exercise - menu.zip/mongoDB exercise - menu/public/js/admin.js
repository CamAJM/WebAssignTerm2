	var id = "";
	var title = "";
	var price = "";
	var idtemp= "";
	var titletemp="";
	var pricetemp="";
	
	
	$(document).ready(function(){
	
		
		 $.getJSON('http://localhost:3000/menu', function(data) {
                
                $.each(data, function(index){
                    
                    
                    var menuitem = data[index]
                    var btnA = "<button id=\""+menuitem._id+"edit\">edit</button>"
					var btnB = "<button id=\""+menuitem._id+"delete\">delete</button>"
					var inputId ="<input id=\""+menuitem._id+"\" value="+menuitem._id+" disabled>";
					var inputTitle ="<input id=\""+menuitem._id+"title\" value=\""+menuitem.title+"\" disabled>";
					var inputPirce ="<input id=\""+menuitem._id+"price\" value="+menuitem.price+">";
			
				
                    $('#old-menu').append(inputId," ",inputTitle," ",inputPirce, " ",btnA," ",btnB, "<BR>")
                    
                    
                    editBtn(menuitem._id,menuitem.title,index)
					deleteBtn(menuitem._id,menuitem.title,index)
                }); 
                
                     
            });
		
			function editBtn(id,title,index)
			{
				var btnEdit = document.getElementById(id+"edit")
				
				btnEdit.addEventListener("click", function(){
					
					var editPrice = document.getElementById(id+"price").value
				
				$.ajax({
					method:"PUT",
					url:"http://localhost:3000/menu/"+title,
					data:{
						price:editPrice
						}
					})
					.done(function( msg ) {
					alert( "Data Saved: " + msg );		
				});	
					
				});
			}
			
			function deleteBtn(id,title,index)
			{
				var btnDelete = document.getElementById(id+"delete")
				
					btnDelete.addEventListener("click", function(){
					
						$.ajax({
						url: "http://localhost:3000/menu/"+id,
						type:"DELETE",
						success:function(result){
							alert("deleted");
						}
	
					});
				});
			}
		
		$( "#submit" ).click(function(){
			 id = $("#id").val();
			 title = $("#title").val();
			 price = $("#price").val();
			
			if (!id || !title || !price)
			{
			alert("please enter valid input");
			}
			var btnXName= id+"edit";
			var btnYName=id+"delete";
			titletemp= id+"title"; 
			pricetemp= id+"price";
				
			
			var btnX= "<button id="+btnXName+">edit</button>";
			var btnY = "<button id="+btnYName+" >delete</button>";
			var inputId ="<input id="+id+" value="+id+" disabled>";
			var inputTitle ="<input id="+titletemp+" value="+title+" disabled>";
			var inputPirce ="<input id="+pricetemp+" value="+price+">";
			
			$('#menu').append(inputId, " ", inputTitle, " ", inputPirce, " ", btnX, " ", btnY, "<BR>");
				
			//var data[] = id, title, price;
			
				
			//$.post( "/add", { 'menuitem[]': [ ""+id+"" ,""+title+"" ,"" +price+"" ] } );
			
			console.log(id,title,price)
			
			
			$.post("http://localhost:3000/add",
                    {
                        _id: id,
                        title: title,
                        price: price
                    },
                    function(data,status){
                        console.log(data,status)
                    });
					
					
			
			
			//$.post( "/add", function( data ) {
			//	$( ".result" ).html( data );
			//});
		});
		
		
		
	});
	
	// this is where the mongo needs to be 
	
	