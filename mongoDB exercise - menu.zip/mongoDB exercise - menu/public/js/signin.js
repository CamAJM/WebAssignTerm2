function signin()
{
	console.log("Hello")

	$.post("http://localhost:3000/login",
	{
	username: document.getElementById("username").value,
	password: document.getElementById("password").value,
	
	},
	function(data,status){
	}); 
	
	
	alert("Login successful")
	window.location.href = "http://localhost:3000/home"
}