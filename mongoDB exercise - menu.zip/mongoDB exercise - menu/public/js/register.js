function register()
{
	console.log("Hello")

	$.post("http://localhost:3000/register",
	{
	username: document.getElementById("username").value,
	password: document.getElementById("password").value,
	firstname: document.getElementById("firstname").value,
	lastname: document.getElementById("lastname").value,
	position: document.getElementById("position").value
	},
	function(data,status){
	}); 
	
	alert("User registered successfully")
	window.location.href = "http://localhost:3000/"
}