

$(document).ready(function(){

	var btnSearch


	$.getJSON('http://localhost:3000/drinks', function(data) {
		var order = [];
		$.each(data, function(index){

			var orderitem = data[index]

			var orderTime = new Date(orderitem.date*1000)
			var hours = orderTime.getHours()
			var minutes = "0" + orderTime.getMinutes()
			var seconds = "0" + orderTime.getSeconds()
			var month = (orderTime.getMonth()+1)
			var date = orderTime.getDate()

			var time = date + "/" + month +" "+ hours + ":" + minutes.substr(-2) 


			document.getElementById('hello').innerHTML += ("<tr><td>"+orderitem.tableId+"</td><td>"+orderitem.title+"</td><td>"+time+"</td></tr>")



		}); 


	});


});

/*
function sortTable() {
	var table, rows, switching, i, x, y, shouldSwitch;
	table = document.getElementById("myTable");
	switching = true;


	while (switching) {
		// Start by saying: no switching is done:
		switching = false;
		rows = table.getElementsByTagName("TR");

		for (i = 1; i < (rows.length - 1); i++) {
			// Start by saying there should be no switching:
			shouldSwitch = false;

			x = rows[i].getElementsByTagName("TD")[0];
			y = rows[i + 1].getElementsByTagName("TD")[0];
			// Check if the two rows should switch place:
			if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
				// I so, mark as a switch and break the loop:
				shouldSwitch= true;
				break;
			}
		}
		if (shouldSwitch) {

			rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
			switching = true;
		}
	}
}
 */
