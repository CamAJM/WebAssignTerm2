
var btnSearch

var socket = io.connect('http://localhost:3000/bar');

$.getJSON('http://localhost:3000/drinks', function(data) {
	var order = [];
	$.each(data, function(index){

		var orderitem = data[index]

		var orderTime = new Date(orderitem.date*1000)
		var hours = orderTime.getHours()
		var minutes = "0" + orderTime.getMinutes()
		var seconds = "0" + orderTime.getSeconds()
		var month = (orderTime.getMonth()+1)
		var date = orderTime.getDate()

		var time = date + "/" + month +" "+ hours + ":" + minutes.substr(-2) 


		document.getElementById('hello').innerHTML += ("<tr><td>"+orderitem.tableId+"</td><td>"+orderitem.title+"</td><td>"+time+"</td></tr>")



	}); 
});

socket.on('chat message', function(msg){
		console.log(msg)

});


