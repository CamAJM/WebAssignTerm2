
var order = [];
var totalPrice = 0
var uniqueOrders = [];
var j = 0

$(document).ready(function(){

	var btnSearch
	var orderitem
	
	run()
	
	function run()
	{
		var table = document.getElementById('orders')
		$(table).empty()
		
		$.getJSON('http://localhost:3000/bills', function(data) {
			$.each(data, function(index){

				orderitem = data[index]

				order.push(orderitem.orderId)


				if($.inArray(orderitem.orderId, uniqueOrders) == -1) uniqueOrders.push(orderitem.orderId)

			}); 
			createTable()
			calculateTotal()

		});
		
		setTimeout(run, 4000)
	}
	
});
function refresh()
{
	createTable()
	calculateTotal()
}
function goaway(id)
{
	var table = document.getElementById(id)
	$(table).remove()
}

function createTable()
{

	$.each(uniqueOrders, function (y){
		$.getJSON('http://localhost:3000/billitems/'+uniqueOrders[y], function(data) {
			
			
			var theaders = "<th>Order Number</th><th>Table Number</th><th>Item</th><th>Time</th><th>Price</th><th>Is Payed?</th>"
			document.getElementById('orders').innerHTML += ("<table id="+data[y].orderId+">"+theaders+"</table>")
			
			$.each(data, function(index){
				
				var orderTime = new Date(data[index].date*1000)
				var hours = orderTime.getHours()
				var minutes = "0" + orderTime.getMinutes()
				var seconds = "0" + orderTime.getSeconds()
				var month = (orderTime.getMonth()+1)
				var date = orderTime.getDate()
				var time = date + "/" + month +" "+ hours + ":" + minutes.substr(-2) 
				document.getElementById(data[y].orderId).innerHTML += ("<tr><td>"+data[index].orderId+"</td><td>"+data[index].tableId+"</td><td>"+data[index].title+"</td><td>"+time+"</td><td>"+data[index].price+"</td><td>"+data[index].isPayed+"</td></tr>")
				
				
			});
			

		});
		
	});
	
}

function calculateTotal()
{
	
	$.each(uniqueOrders, function (y){
		$.getJSON('http://localhost:3000/billitems/'+uniqueOrders[y], function(data) {

			$.each(data, function(index){
				totalPrice=totalPrice+data[index].price
				
			});
			var pay = "<button id="+uniqueOrders[y]+"P>Payed</button>"
			var orderId = data[y].orderId
			
			document.getElementById(orderId).innerHTML+= ("<tr><td>Total price for order number "+ data[y].orderId+ ": "+totalPrice+"</td><td>"+ pay +"</td></tr>")
			var paybtn = document.getElementById(uniqueOrders[y]+"P")
			paybtn.addEventListener("click", function(){
				console.log(data[y].orderId)
				
				$.ajax({
					type:"PUT",
					url:"http://localhost:3000/pay/"+orderId,
					data:{
						isPayed:true
						}
					})
					.done(function( msg ) {
					alert( "Order is now payed" );
					goaway(data[y].orderId)
					
					
				});		
				
			});
			
			
			totalPrice = 0

		});
	});
	
}
