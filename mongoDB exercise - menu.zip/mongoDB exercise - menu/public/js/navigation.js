$(document).ready(function(){

	document.getElementById("navBar").innerHTML =
		'<a class=views href="http://localhost:3000/home">Home </a>'+

		'<a class=views href="http://localhost:3000/waiter">Waiter View </a>'+

		'<a class=views href="http://localhost:3000/kitchen">Kitchen View </a>'+

		'<a class=views href="http://localhost:3000/bar">Bar View </a>'+

		'<a class=views href="http://localhost:3000/counter">Counter View </a>'+

		'<a class=views href="http://localhost:3000/admin">Admin View </a>'+
	
		'<a class=views href="http://localhost:3000/logout">Signout </a>';


});