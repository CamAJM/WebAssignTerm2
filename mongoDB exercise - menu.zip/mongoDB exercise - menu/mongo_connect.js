var express = require('express');
var app = new express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var MenuItem = require('./menu.model');
// Creates an instance of menu.model

var myDB = 'mongodb://localhost:27017/menu';
// Connects with the database.



mongoose.connect(myDB, function(err){
	if(err){
		console.log(err);
	} else{
		console.log('ok');
	}
});

