var mongoose = require('mongoose');
var Schema = mongoose.Schema; 
var billItemSchema = new Schema({
	orderId: Number,
	tableId: Number,
	foodId: Number,
	title: { type: String, uppercase: true },
	price: Number,
	isPayed: Boolean,
	date: String
	
});

module.exports = mongoose.model('BillItem', billItemSchema); 
// Finds the collection menuitem. Mongo adds an s to the collection name here. So while "menuitem" is entered, Mongo looks for "menuitems".
