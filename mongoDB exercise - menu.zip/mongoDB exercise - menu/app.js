var express = require('express');
var session = require('express-session')
var app = new express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var MenuItem = require('./menu.model');
var OrderItem = require('./orders.model')
var DrinkItem =  require('./drinks.model')
var BillItem = require('./bills.model')
var User = require('./user');
var path = require('path')
/*
var server = require('http').createServer(app);
var io = require('socket.io')(server);
*/
// Struggled to get socket set up properly. Couldn't figure out how it would work with
// Mongoose.

var myDB = 'mongodb://localhost:27017/menu';
mongoose.connect(myDB, function(err){
	if(err){
		console.log(err);
	} else{
		console.log('ok');
	}
});


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(session({secret: 'this-is-a-secret-token', cookie:{maxAge:60000}}))
app.use("/public", express.static(__dirname + "/public"));


app.get('/', function(req, res){
	res.sendFile(path.join(__dirname, 'public/views/signin.html'))
	
});

app.get('/chat', function(req, res){
	res.sendFile(path.join(__dirname, 'public/views/chat.html'))
	
});



app.get('/home', function(req,res){
	var position = req.session.position
	console.log(position)
	if(position=="Admin")
	{
		res.sendFile(path.join(__dirname, 'public/views/index.html'))
	}
	else if(position=="Customer")
	{
		res.sendFile(path.join(__dirname, 'public/views/indexCust.html'))
	}
	else
	{
		res.send("You do not have permission for that.")
	}
});


app.get('/signup', function(req,res){
	res.sendFile(path.join(__dirname, 'public/views/register.html'))
});

app.get('/kitchen', function(req,res){
	res.sendFile(path.join(__dirname, 'public/views/kitchen.html'))
});

app.get('/counter', function(req,res){
	res.sendFile(path.join(__dirname, 'public/views/counter.html'))
});

app.get('/bar', function(req,res){
	res.sendFile(path.join(__dirname, 'public/views/bar.html'))

});

app.get('/admin', function(req,res){
	var position = req.session.position
	if (position=="Admin")
	{
		res.sendFile(path.join(__dirname, 'public/views/admin.html'))
	}
	else
	{
		res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
		
});

app.get('/waiter', function(req,res){
	var newItem = new MenuItem()
	newItem = req.query.newItem
	res.sendFile(path.join(__dirname, 'public/views/waiter.html'))
	
});

app.get('/menu', function(req, res){
	MenuItem.find({}, function(err, results){
		res.send(results);
	});
});

app.get('/latest', function(req,res){
	OrderItem.findOne().sort({ field: 'asc', _id: -1 }).limit(1).exec(function (err, results){
		res.send(results)
	});
	
});


app.get('/orders', function(req,res){
	OrderItem.find({}, function(err, results){
		res.send(results)
	});
});


app.get('/drinks', function(req,res){
	
	DrinkItem.find({}, function(err, results){
		res.send(results);
	});
	
});
/*
io.on('connection', function(socket){
  socket.on('chat message', function(msg){
    io.emit('chat message', msg);
  });
});
*/

app.get('/bills', function(req,res){
	BillItem.find({isPayed: false}, function(err,results){
		res.send(results)
	});
});


app.get('/menu/:title', function(req, res){
	MenuItem.findOne({title: req.params.title}, function(err, result){
		try{
			var newItem = new MenuItem()
			newItem._id = result._id;
			newItem.title = result.title;
			newItem.price = result.price;
			res.send(newItem)
			console.log(newItem)
		}catch(e)
		{
			res.send("Item does not exist.")
		}
	});
	
});

app.get('/billitems/:orderId', function(req, res){
	BillItem.find({orderId: req.params.orderId}, function(err, result){
		res.send(result)
	});
	
});

app.post('/menu', function(req, res){
	var newItem = new MenuItem();
	newItem._id = req.body._id;
	newItem.title = req.body.title;
	newItem.price = req.body.price;
	newItem.save(function(err, result){
		res.send(result);
	});
	res.end()

});
// Adds to menu
app.post('/add', function(req, res){
	MenuItem.create(req.body, function(err, result){
	});
	res.end()

});

app.post('/addDrink', function(req,res){
	DrinkItem.create(req.body, function(err, result){
	});
	res.end()
	
});

app.post('/addBill', function(req,res){
	BillItem.create(req.body, function(err, result){
	});
	res.end()
});

//Adds to orders
app.post('/addOrder', function(req,res){
	OrderItem.create(req.body, function(err, result){
	});
	res.end()
	
});

app.put('/pay/:orderId',function(req,res){
	BillItem.update({orderId: req.params.orderId},{$set:{isPayed: req.body.isPayed}},{multi: true}, function(err, result){
	});
	res.end()
});
	
app.put('/menu/:title', function(req, res){
	MenuItem.findOneAndUpdate({title: req.params.title},{$set:{price: req.body.price}}, function(err, result){
		res.send(result);
	});
});

app.delete('/menu/:id', function(req, res){
	MenuItem.remove({_id: req.params.id}, function(err, result){
		res.send(result);
	});
	res.end()
});




app.post('/login', function(req, res) {
	var username = req.body.username;
	var password = req.body.password;
	
	User.findOne({username: username, password: password}, function (err, user) {
		if(err){
			
			console.log(err);
			return res.status(500).send();
		}
		if(!user){
		return res.status(404).send();
	}
		var sessData = req.session
		sessData.position = user.position

		return res.status(200).send();
		
	})


});


app.get('/logout', function(req, res) {
	
	req.session.destroy();
	
	res.sendFile(path.join(__dirname, 'public/views/signin.html'))

});


app.post('/register', function(req, res) {
	User.create(req.body, function(err, result){
		(path.join(__dirname, 'public/views/index.html'))
	});
	res.end()	
	
});



app.listen(3000)
