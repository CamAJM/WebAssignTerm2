var mongoose = require('mongoose');
var Schema = mongoose.Schema; 
var drinkItemSchema = new Schema({
	orderId: Number,
	tableId: Number,
	foodId: Number,
	title: { type: String, uppercase: true },
	date: String
	
});

module.exports = mongoose.model('DrinkItem', drinkItemSchema); 
// Finds the collection menuitem. Mongo adds an s to the collection name here. So while "menuitem" is entered, Mongo looks for "menuitems".
