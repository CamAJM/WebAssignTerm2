var express = require('express');
var session = require('express-session')
var app = new express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var MenuItem = require('./menu.model');
var ActiveTable = require('./tables.model');
var OrderItem = require('./orders.model')
var DrinkItem =  require('./drinks.model')
var BillItem = require('./bills.model')
var User = require('./user');
var path = require('path')
/*
var server = require('http').createServer(app);
var io = require('socket.io')(server);
*/
// Struggled to get socket set up properly. Couldn't figure out how it would work with
// Mongoose.

var myDB = 'mongodb://localhost:27017/menu';
mongoose.connect(myDB, function(err){
	if(err){
		console.log(err);
	} else{
		console.log('ok');
	}
});


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(session({secret: 'this-is-a-secret-token', cookie:{maxAge:86400000}}))
app.use("/public", express.static(__dirname + "/public"));


function isStaff(position)
{
	if(position == "Staff" || position == "Admin")
	{
		return true
	}
	else
	{
		return false
	}
	
}


app.get('/', function(req, res){
	var position = req.session.position
	if(position)
	{
		res.sendFile(path.join(__dirname, 'public/views/index.html'))
	}
	else
	{
		res.sendFile(path.join(__dirname, 'public/views/signin.html'))
	}
});

app.get('/online', function(req, res){
	var position = req.session.position

	if(position)
	{
		res.sendFile(path.join(__dirname, 'public/views/online.html'))
	}
	else
	{
		res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
	
	
});


app.get('/home', function(req,res){
	var position = req.session.position
	if(position=="Admin")
	{
		res.sendFile(path.join(__dirname, 'public/views/index.html'))
	}
	else if(position=="Customer")
	{
		res.sendFile(path.join(__dirname, 'public/views/indexCust.html'))
	}
	else if(position=="Staff")
	{
		res.sendFile(path.join(__dirname, 'public/views/indexStaff.html'))
	}
	else
	{
		res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
});


app.get('/signup', function(req,res){
	var position = req.session.position

	if(!position)
	{
		res.sendFile(path.join(__dirname, 'public/views/register.html'))
	}
	else
	{
		res.send("You already have an account!")
	}
	
});

app.get('/kitchen', function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	   res.sendFile(path.join(__dirname, 'public/views/kitchen.html'))
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
		
		

});

app.get('/counter', function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	   res.sendFile(path.join(__dirname, 'public/views/counter.html'))
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
		
});

app.get('/summary', function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	   res.sendFile(path.join(__dirname, 'public/views/oneWeek.html'))
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
});


app.get('/bar', function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	   res.sendFile(path.join(__dirname, 'public/views/bar.html'))
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}

});

app.get('/admin', function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	   res.sendFile(path.join(__dirname, 'public/views/admin.html'))
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
		
});

app.get('/waiter', function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	   res.sendFile(path.join(__dirname, 'public/views/waiter.html'))
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
	
	
});

app.get('/menu', function(req, res){
	
	var position = req.session.position

	if(position)
	{
	   MenuItem.find({}, function(err, results){
			res.send(results);
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
	
	
});

app.get('/staff', function(req, res){
	var position = req.session.position
	if(position)
	{
	   User.find({}, function(err, results){
			res.send(results);
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
	
});


app.get('/latest', function(req,res){
	
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	  BillItem.findOne().sort({ field: 'asc', _id: -1 }).limit(1).exec(function (err, results){
			res.send(results)
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
	
});


app.get('/orders', function(req,res){
	
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	    OrderItem.find({}, function(err, results){
			res.send(results)
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
	
});


app.get('/drinks', function(req,res){
	var position = req.session.position
	var staff = isStaff(position)

	if(staff )
	{
	    DrinkItem.find({}, function(err, results){
			res.send(results);
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
});
/*
io.on('connection', function(socket){
  socket.on('chat message', function(msg){
    io.emit('chat message', msg);
  });
});
*/

app.get('/bills', function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	    BillItem.find({isPayed: false}, function(err,results){
			res.send(results)
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
});


app.get('/menu/:title', function(req, res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	    MenuItem.findOne({title: req.params.title}, function(err, result){
			try{
				var newItem = new MenuItem()
				newItem._id = result._id;
				newItem.title = result.title;
				newItem.price = result.price;
				res.send(newItem)
			}catch(e)
			{
				res.send("Item does not exist.")
			}
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}		
	
});

app.get('/billitems/:orderId', function(req, res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	    BillItem.find({orderId: req.params.orderId}, function(err, result){
			res.send(result)
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
	
});

app.get('/activetables/:_id', function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	    ActiveTable.find({_id: req.params._id}, function(err, result){
			res.send(result)
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
});

app.post('/menu', function(req, res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	    var newItem = new MenuItem();
		newItem._id = req.body._id;
		newItem.title = req.body.title;
		newItem.price = req.body.price;
		newItem.save(function(err, result){
			res.send(result);
		});
		res.end()
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}

});
// Adds to menu
app.post('/add', function(req, res){
	var position = req.session.position

	if(position)
	{
	    MenuItem.create(req.body, function(err, result){
		});
		res.end()
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
	
});



app.get('/oneWeekQ', function(req,res){
	var d = new Date();
	d.setDate(d.getDate()-7)
	d = d.getTime()/1000
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	    BillItem.find({date:{$gt: d}}, function(err,result){
			res.send(result)
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
	
});

app.post('/userinsert', function(req, res){
	var position = req.session.position

	var staff = "Admin"
	if(staff )
	{
	    User.create(req.body,function(err,result){	
		});
		res.end()
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
});


app.post('/addDrink', function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
		DrinkItem.create(req.body, function(err, result){
		});
		res.end()
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
	
	
});

app.post('/activeTable', function(req,res){
	var position = req.session.position
	
	var staff = isStaff(position)
	if(staff )
	{
		ActiveTable.create(req.body, function(err, result){
		});
		res.end()
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}
});

app.post('/addBill', function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
	    BillItem.create(req.body, function(err, result){
		});
		res.end()
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
});

//Adds to orders
app.post('/addOrder', function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
		OrderItem.create(req.body, function(err, result){
		});
		res.end()
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
});

app.put('/pay/:orderId',function(req,res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
		BillItem.update({orderId: req.params.orderId},{$set:{isPayed: req.body.isPayed}},{multi: true}, function(err, result){
		});
		res.end()
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
});
	
app.put('/menu/:title', function(req, res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
		MenuItem.findOneAndUpdate({title: req.params.title},{$set:{price: req.body.price}}, function(err, result){
			res.send(result);
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
});

app.put('/staff/:username', function(req, res){
	var staff = isStaff(position)
	if(staff )
	{
		User.findOneAndUpdate({username: req.params.username},{$set:{firstname: req.body.firstname, lastname: req.body.lastname, position: req.body.position}}, function(err, result){
		res.send(result);
	});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
});

app.delete('/menu/:id', function(req, res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
		MenuItem.remove({_id: req.params.id}, function(err, result){
			res.send(result);
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
});

app.delete('/staffremove/:username', function(req, res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
		User.remove({username: req.params.username}, function(err, result){
			res.send(result);
		});	
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
});


app.delete('/kitchen/:id', function(req, res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
		OrderItem.remove({_id: req.params.id}, function(err, result){
			res.send(result);
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
	
});

app.delete('/table/:orderId', function(req, res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
		ActiveTable.remove({orderId: req.params.orderId}, function(err, result){
			res.send(result);
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
	
});

app.delete('/bar/:id', function(req, res){
	var position = req.session.position

	var staff = isStaff(position)
	if(staff )
	{
		DrinkItem.remove({_id: req.params.id}, function(err, result){
			res.send(result);
		});
	}
	else
	{
	   res.sendFile(path.join(__dirname, 'public/views/401.html'))
	}	
	
	
});


app.post('/login', function(req, res) {
	var position = req.session.position
	
	if(!position)
	{
		var username = req.body.username;
		var password = req.body.password;
	
		User.findOne({username: username, password: password}, function (err, user) {
			if(err){

				console.log(err);
				return res.status(500).send();
			}
			if(!user){
			return res.status(404).send();
			}
			var sessData = req.session
			sessData.position = user.position

			return res.status(200).send();
		})
	}
	else
	{
	   res.send("You are already logged in!")
	}
	
	


});


app.get('/logout', function(req, res) {
	var position = req.session.position
	
	if(position)
	{
		req.session.destroy();
		res.sendFile(path.join(__dirname, 'public/views/signin.html'))
	}
	else
	{
		res.send("You aren't logged in! <a href=\"http://localhost:3000/\">Click here to do so!</a>")
	}
	
	
});


app.post('/register', function(req, res) {
	var position = req.session.position
	if(!position)
	{
		User.create(req.body, function(err, result){
			(path.join(__dirname, 'public/views/index.html'))
		});
		res.end()		
	}
	else
	{
		res.send("Please log out before doing this.")
	}
	
	
});



app.listen(3000)
