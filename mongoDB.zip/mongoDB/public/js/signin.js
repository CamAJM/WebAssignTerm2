function signin()
{
	$.ajax({
		url: "http://localhost:3000/login",
		data:{
			username: document.getElementById("username").value,
			password: document.getElementById("password").value
		},
		type: 'post',
		error: function(XMLHttpRequest, textStatus, errorThrown)
		{
			var status = XMLHttpRequest.status;
			if(status==404)
			{
				alert("Check your details!")
			}
			else
			{
				alert("Something went wrong. If this error persists, please inform an administrator.")
			}
    	},
		success: function(data)
		{
			alert("Login successful")
			document.location.href= "http://localhost:3000/home"
		}
	});
	
	
}