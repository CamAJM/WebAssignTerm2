$(document).ready(function(){
	 $.getJSON('http://localhost:3000/oneWeekQ', function(data) {
		
		var total = 0
	    var orders = document.getElementById('orders')

		
		orders.innerHTML += "<table id=table><th>Title</th><th>Price</th><th>Date</th></table>"
		
		var table = document.getElementById("table")

		$.each(data, function(index){

			var date = new Date(data[index].date*1000)
			var day = date.getDate()
			
			var newdate = date 
			
			
			console.log(data[index])
			table.innerHTML += "<tr><td>"+data[index].title+"</td><td>"+data[index].price+"</td><td>"+newdate+"</td></tr>" 
			total = total + data[index].price
		}); 
		table.innerHTML += "<tr><td>Total Income: £"+total+"</td></tr>"

	});

});