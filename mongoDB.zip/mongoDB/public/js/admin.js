	var id = "";
	var title = "";
	var price = "";
	var idtemp= "";
	var titletemp="";
	var pricetemp="";
	
	
	
	
	
	$(document).ready(function(){
	
		
		 $.getJSON('http://localhost:3000/menu', function(data) {
                
				
				
                $.each(data, function(index){
                    
                    
                    var menuitem = data[index]
                    var btnA = "<button class=btnStyle id=\""+menuitem._id+"edit\">edit</button>"
					var btnB = "<button class=btnStyle id=\""+menuitem._id+"delete\">delete</button>"
					var inputId ="<input class=textStyle type='number' id=\""+menuitem._id+"\" value="+menuitem._id+" disabled>";
					var inputTitle ="<input class=textStyle id=\""+menuitem._id+"title\" value=\""+menuitem.title+"\" disabled>";
					var inputPirce ="<input class=textStyle type='number' id=\""+menuitem._id+"price\" value="+menuitem.price+">";
			
                    $('#old-menu').append(inputId," ",inputTitle," ",inputPirce, " ",btnA," ",btnB, "<BR>")
                    
                    
                    editBtn(menuitem._id,menuitem.title,index)
					deleteBtn(menuitem._id,menuitem.title)
                }); 
                
                     
            });
		
		
		$.getJSON('http://localhost:3000/staff', function(data) {
			
			$.each(data,function(index){
				
				var staffmembers = data[index]
				var btnC = "<button class=btnStyle id=\""+staffmembers.username+"edit\">edit</button>";
				var btnD = "<button class=btnStyle id=\""+staffmembers.username+"delete\">delete</button>";
				var inputUsername ="<input class=textStyle id=\""+staffmembers.username+"\" value="+staffmembers.username+" disabled>";
				var inputFname ="<input class=textStyle id=\""+staffmembers.username+"fname\" value=\""+staffmembers.firstname+"\">";
				var inputLname ="<input class=textStyle id=\""+staffmembers.username+"lname\" value="+staffmembers.lastname+">";
				var inputadmin = "<select class=textStyle id=\""+staffmembers.username+"position\"><option value='Admin'>Admin</option><option value='Staff'>Staff</option><option value='Customer'>Customer</option></select>"
				
				
				$('#staff').append(inputUsername," ",inputFname," ",inputLname," ", inputadmin, " ",btnC," ",btnD, "<BR>");
				document.getElementById(staffmembers.username+"position").value = staffmembers.position;
				editBtnStaff(staffmembers.username)
				deleteBtnStaff(staffmembers.username)
				
			});
			
		});	
			
		
			function editBtn(id,title,index)
			{
				var btnEdit = document.getElementById(id+"edit")
				
				btnEdit.addEventListener("click", function(){
					
					var editPrice = document.getElementById(id+"price").value
				
				$.ajax({
					method:"PUT",
					url:"http://localhost:3000/menu/"+title,
					data:{
						price:editPrice
						}
					})
					.done(function( msg ) {
					alert( "Data Saved: " + msg );
					loadstaff();
				});	
					
				});
			}
			
			function editBtnStaff(username)
			{
				var btnEdit = document.getElementById(username+"edit")
				
				btnEdit.addEventListener("click", function(){
					
					var editUser = document.getElementById(username).value
					var editF = document.getElementById(username+"fname").value
					var editL = document.getElementById(username+"lname").value
					var editA = document.getElementById(username+"position").value
				$.ajax({
					method:"PUT",
					url:"http://localhost:3000/staff/"+username,
					data:{
						username: editUser,
						firstname: editF,
						lastname: editL,
						position: editA
						}
					})
					.done(function( msg ) {
					alert( "Data Saved: " + msg );		
				});	
					
				});
				
				
			} 
			
			
			function deleteBtn(id,title)
			{
				var btnDelete = document.getElementById(id+"delete")
				
					btnDelete.addEventListener("click", function(){
					
						$.ajax({
						url: "http://localhost:3000/menu/"+id,
						type:"DELETE",
						success:function(result){
							alert("deleted");
							location.reload();
						}
	
					});
				});
			}
			
			function deleteBtnStaff(username)
			{
				var btnDelete = document.getElementById(username+"delete")
					btnDelete.addEventListener("click", function(){
					
						$.ajax({
						url: "http://localhost:3000/staffremove/"+username,
						type:"DELETE",
						success:function(result){
							alert("deleted");
							location.reload();
						}
	
					});
				});
				
			}
		
		$( "#submitFood" ).click(function(){
			 id = $("#id").val();
			 title = $("#title").val();
			 price = $("#price").val();
			
			if (!id || !title || !price)
			{
				alert("please enter valid input");
			}
			else
			{
				var btnXName= id+"edit";
				var btnYName=id+"delete";
				titletemp= id+"title"; 
				pricetemp= id+"price";


				var btnX= "<button class=btnStyle id="+btnXName+">edit</button>";
				var btnY = "<button class=btnStyle id="+btnYName+" >delete</button>";
				var inputId ="<input class=textStyle type='number' id="+id+" value="+id+" disabled>";
				var inputTitle ="<input class=textStyle id="+titletemp+" value="+title+" disabled>";
				var inputPirce ="<input class=textStyle type='number' id="+pricetemp+" value="+price+">";

				$('#menu').append(inputId, " ", inputTitle, " ", inputPirce, " ", btnX, " ", btnY, "<BR>");

				//var data[] = id, title, price;


				//$.post( "/add", { 'menuitem[]': [ ""+id+"" ,""+title+"" ,"" +price+"" ] } );

				console.log(id,title,price);


				$.post("http://localhost:3000/add",
						{
							_id: id,
							title: title,
							price: price
						},
						function(data,status){
							console.log(data,status)
						});
				}
			});
			
	
		
		 $( "#newUser" ).click(function(){
			
			var username = $("#userName").val();
			console.log(username)
			var passIn = $("#userPassword").val();
			var fname = $("#userFName").val();
			var lname = $("#userLName").val();
			var position = $("#userPosition").val();
			 
			 if(username || passIn || fname || lname || position)
			 {
			
			
				$.post("http://localhost:3000/userinsert",
				{
					username: username,
					pass: passIn,
					firstname: fname,
					lastname: lname,
					position: position
				}, function(data,status){
                        console.log(data,status);
						
						var btnC = "<button class=btnStyle id=\""+username+"edit\">edit</button>";
						var btnD = "<button class=btnStyle id=\""+username+"delete\">delete</button>";
						var inputUsername ="<input class=textStyle id=\""+username+"\" value="+username+">";
						var inputFname ="<input class=textStyle id=\""+username+"fname\" value=\""+fname+"\">";
						var inputLname ="<input class=textStyle id=\""+username+"lname\" value="+lname+">";
						var inputadmin = "<select id=\""+username+"position\"><option value='Admin'>Admin</option><option value='Staff'>Staff</option><option value='Customer'>Customer</option></select>"	
	
						$('#staff').append(inputUsername, " ", inputFname, " ", inputLname, " ",inputadmin , " ", btnC, " ", btnD, "<BR>");
						
						document.getElementById(staffmembers.username+"position").value = position;
                });	
			 }
		});  
			
			
	});
	
	
	
	