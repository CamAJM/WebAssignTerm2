 var order = []
 var btns = []
 var j = 0
 var ids = []
 var orderNo = 1

$(document).ready(function(){
	
	var btnSearch
		
	
	 $.getJSON('http://localhost:3000/latest', function(data) {

		 var last = data.orderId;

		 orderNo = last + 1

	 })
	
	  

	$.getJSON('http://localhost:3000/menu', function(data) {
		var order = [];
		$.each(data, function(index){


			var menuitem = data[index]
			var btnP = "<button class='btnStyle'id=\""+menuitem.title+"\">+</button>"

			$('#hello').append("<div id='test'>",menuitem.title, " ",btnP,"</div>", "<br>")


			createBtn(menuitem.title, menuitem._id, index)

		}); 


	});


});

// Adds an entry to the menu and provides a remove button.
function createBtn(title, id, index)
{
	btnSearch = document.getElementById(title)
	order.push(title)



	btnSearch.addEventListener("click", function(){

	   var btnD = "<button class='btnStyle' type=button id=\""+j+"D\">-</button>"
		document.getElementById("goodbye").innerHTML += "<div id='test1'><input type=\"text\" id=\""+id+j+"\" name=\"items\" value=\""+order[index]+"\" readonly>"+btnD+"</div><br>"
		btns.push(j)
		newID = ("" + id + j)
		ids.push(newID)

		// Function call has to be here as unless this event is triggered, the remove button will not even exist.
		deleteBtn(id)

		j++
	});    
}

// Trigger for the remove button
function deleteBtn(id)
{
	var item = document.getElementsByName("items")

	$.each(ids, function(index){

		var item = document.getElementById(ids[index])

		$.each(btns, function(){

			var btnRemove = document.getElementById(btns[index]+"D")

			btnRemove.addEventListener("click", function(){
				btns.splice(index)
				$(btnRemove).remove()
				$(item).remove()
				ids.splice(index)

			});

		});
	});

}

function createItem()
{
	var tableNo = document.getElementById("tNo").value
	var ts = Math.round((new Date()).getTime() / 1000);
	
	$.get('http://localhost:3000/activetables/'+tableNo, function(data)
	{
		var items = document.getElementsByName("items")

		if(!data.length > 0)
		{
				// Table does not exist
			$.each(items, function(index){

				var item = items[index].value

				$.getJSON('http://localhost:3000/menu/'+item, function(data) {

					/*
					var socket = io.connect('http://localhost:3000/bar');

					  socket.emit('chat message', orderNo + " " + tableNo);


					socket.on('chat message', function(msg){



						$('#hello').append($('<li>').text(msg));
					  window.scrollTo(0, document.body.scrollHeight);
					});
					*/
					j++
					$.post("http://localhost:3000/addBill",
					{
					orderId: orderNo,
					tableId: tableNo,
					title: data.title,
					price: data.price,
					isPayed: false,
					date: ts
					},
					function(data,status){
					}); 

					$.post("http://localhost:3000/activeTable",
					{
					_id: tableNo,
					orderId: orderNo
					},
					function(data,status){
					}); 

					if(data._id>=200)
					{
					   $.post("http://localhost:3000/addOrder",
						{
						_id:j,
						orderId: orderNo,
						tableId: tableNo,
						title: data.title,
						date: ts
						},
						function(data,status){
						}); 
					}
					else if(data._id<200)
					{
						$.post("http://localhost:3000/addDrink",
						{
						_id:j,
						orderId: orderNo,
						tableId: tableNo,
						title: data.title,
						date: ts
						},
						function(data,status){
						}); 
					}
					else
					{
						alert("Error")
					}

				});


			});
			alert("Order placed")
		}
		else
		{
			var addOrder = data[0].orderId
			console.log(items)
			//Table exists
			$.each(items, function(index){

				var item = items[index].value
				console.log(item)

				$.getJSON('http://localhost:3000/menu/'+item, function(data) {

					j++
					console.log(addOrder)

					$.post("http://localhost:3000/addBill",
					{
						orderId: addOrder,
						tableId: tableNo,
						title: data.title,
						price: data.price,
						isPayed: false,
						date: ts
					},
					function(data,status){
					}); 

					$.post("http://localhost:3000/activeTable",
					{
						_id: tableNo,
						orderId: orderNo
					},
					function(data,status){
					}); 

					if(data._id>=200)
					{
					   $.post("http://localhost:3000/addOrder",
						{
						_id:j,
						orderId: addOrder,
						tableId: tableNo,
						title: data.title,
						date: ts
						},
						function(data,status){
						}); 
					}
					else if(data._id<200)
					{
						$.post("http://localhost:3000/addDrink",
						{
						_id:j,
						orderId: addOrder,
						tableId: tableNo,
						title: data.title,
						date: ts
						},
						function(data,status){
						}); 
					}
					else
					{
						alert("Error")
					}

				});
			});
		   //alert("Order added.")
		}
	});
	//location.reload()
}