$(document).ready(function(){

	var orderResult = document.getElementById('orderResult')
	orderResult.style.visibility = "hidden"
	var all = document.getElementById('showAll')
	all.style.visibility = "hidden"

});
var order = [];
var totalPrice = 0
var uniqueOrders = [];
var j = 0

var btnSearch
var orderitem

run()

function run()
{
	var table = document.getElementById('orders')
	$(table).empty()
	$.getJSON('http://localhost:3000/bills', function(data) {
		$.each(data, function(index){

			orderitem = data[index]
			order.push(orderitem.orderId)
			


			if($.inArray(orderitem.orderId, uniqueOrders) == -1) uniqueOrders.push(orderitem.orderId)
			

		}); 
		createTable()
		calculateTotal()

	});
//	setTimeout(run, 4000)
}

function refresh()
{
	createTable()
	calculateTotal()
}
function remove(id)
{
	var table = document.getElementById(id)
	$(table).remove()
}

function createTable()
{

	$.each(uniqueOrders, function (y){
		$.getJSON('http://localhost:3000/billitems/'+uniqueOrders[y], function(data) {
			console.log(uniqueOrders[y])

			var theaders = "<th>Order Number</th><th>Table Number</th><th>Item</th><th>Time</th><th>Price</th><th>Is Payed?</th>"
			document.getElementById('orders').innerHTML += ("<table id="+uniqueOrders[y]+">"+theaders+"</table>")
			$.each(data, function(index){
				
				var orderTime = new Date(data[index].date*1000)
				var hours = orderTime.getHours()
				var minutes = "0" + orderTime.getMinutes()
				var seconds = "0" + orderTime.getSeconds()
				var month = (orderTime.getMonth()+1)
				var date = orderTime.getDate()
				var time = date + "/" + month +" "+ hours + ":" + minutes.substr(-2) 
				document.getElementById(uniqueOrders[y]).innerHTML += ("<tr><td>"+uniqueOrders[y]+"</td><td>"+data[index].tableId+"</td><td>"+data[index].title+"</td><td>"+time+"</td><td>"+data[index].price+"</td><td>"+data[index].isPayed+"</td></tr>")
				
				
			});
			

		});
		
	});
	
}

function calculateTotal()
{
	
	$.each(uniqueOrders, function (y){
		$.getJSON('http://localhost:3000/billitems/'+uniqueOrders[y], function(data) {

			$.each(data, function(index){
				totalPrice=totalPrice+data[index].price
				
			});
			var pay = "<button class='btnStyle' id="+uniqueOrders[y]+"P>Payed</button>"
			var orderId = uniqueOrders[y]
			
			document.getElementById(orderId).innerHTML+= ("<tr><td>Total price for order number "+ uniqueOrders[y]+ ": "+totalPrice+"</td><td>"+ pay +"</td></tr>")
			var paybtn = document.getElementById(uniqueOrders[y]+"P")
			paybtn.addEventListener("click", function(){
				console.log(data[y].orderId)
				
				$.ajax({
					type:"PUT",
					url:"http://localhost:3000/pay/"+orderId,
					data:{
						isPayed:true
						}
					})
					.done(function( msg ) {
					alert( "Order is now payed" );
					remove(data[y].orderId)
					
					
				});		
				
			});
			
			
			totalPrice = 0

		});
	});
	
}

function findOrder()
{
		var orderId = document.getElementById('orderId').value
		var orderResult = document.getElementById('orderResult')
		var orders = document.getElementById('orders')
		var all = document.getElementById('showAll')
		var totalPrice = 0
		
		all.style.visibility = "visible"

		//orders.style.visibility = "hidden";
		//orderResult.style.visibility = "visible";
		

		var theaders = "<th>Order Number</th><th>Table Number</th><th>Item</th><th>Time</th><th>Price</th><th>Is Payed?</th>"

		
		$(orders).empty();
		
		$(orders).append("<table id=OrderById>"+theaders+"</table>")
		
		$.getJSON('http://localhost:3000/billitems/'+orderId, function(data) {
			$.each(data, function(index){
				var orderTime = new Date(data[index].date*1000)
				var hours = orderTime.getHours()
				var minutes = "0" + orderTime.getMinutes()
				var seconds = "0" + orderTime.getSeconds()
				var month = (orderTime.getMonth()+1)
				var date = orderTime.getDate()
				var time = date + "/" + month +" "+ hours + ":" + minutes.substr(-2) 
				$('#OrderById').append("<tr><td>"+data[index].orderId+"</td><td>"+data[index].tableId+"</td><td>"+data[index].title+"</td><td>"+time+"</td><td>"+data[index].price+"</td><td>"+data[index].isPayed+"</td></tr>")
				totalPrice = totalPrice + data[index].price
				
			});
			paySpecific(data, orderId, totalPrice)
			
		});
		
		

}

function paySpecific(data, index, totalPrice)
{
	var orderitem = data[index]
	var pay = "<button id="+index+"P>Payed</button>"
	var orderId = index

	document.getElementById('OrderById').innerHTML+= ("<tr><td>Total price for order number "+ orderId+ ": "+totalPrice+"</td><td>"+ pay +"</td></tr>")
	var paybtn = document.getElementById(orderId+"P")
	paybtn.addEventListener("click", function(){
		console.log(data[index].orderId)

		$.ajax({
			type:"PUT",
			url:"http://localhost:3000/pay/"+orderId,
			data:{
				isPayed:true
				}
			})
			.done(function( msg ) {
			alert( "Order is now payed" );
			remove(data[y].orderId)


		});		

	});
}

