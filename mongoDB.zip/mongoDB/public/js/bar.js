
var btnSearch



$.getJSON('http://localhost:3000/drinks', function(data) {
	var order = [];
	$.each(data, function(index){

		var orderitem = data[index]

		var orderTime = new Date(orderitem.date*1000)
		var hours = orderTime.getHours()
		var minutes = "0" + orderTime.getMinutes()
		var seconds = "0" + orderTime.getSeconds()
		var month = (orderTime.getMonth()+1)
		var date = orderTime.getDate()

		var time = date + "/" + month +" "+ hours + ":" + minutes.substr(-2) 
		var btnP = "<button id=\""+orderitem._id+"delete"+"\">-</button>"

		
		 $('#hello1').append("<tr id="+orderitem._id+"D"+"><td>"+orderitem.orderId+"</td><td>"+orderitem.tableId+"</td><td>"+orderitem.title+"</td><td>"+time+"</td><td>"+btnP+"</td></tr>")
	deleteBtn(orderitem._id)

	}); 
});

		function deleteBtn(id)
			{
				var btnDelete = document.getElementById(id+"delete")
				console.log(btnDelete);
					btnDelete.addEventListener("click", function(){
						$("#"+id+"D").remove()
						$.ajax({
						url: "http://localhost:3000/bar/"+id,
						type:"DELETE",
						success:function(result){
							alert("deleted");
						}
					
					});
				});
			}
			



