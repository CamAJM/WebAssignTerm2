var order = []
var btns = []
var j = 0
var ids = []
var orderNo = 1;
var counter =1;
$(document).ready(function(){

$.getJSON('http://localhost:3000/latest', function(data) {

var last = data.orderId;
console.log(last)
orderNo = last + 1 ;
}); 
$.getJSON('http://localhost:3000/menu', function(data) {
var order = [];
$.each(data, function(index){
var menuitem = data[index]
var btnP = "<button class='btnStyle' id=\""+menuitem._id+"add\">+</button>"
var inputId = "<input class='textStyle' id=\""+menuitem._id+"\" value="+menuitem._id+" disabled>";
var inputTitle = "<input class='textStyle' id=\""+menuitem._id+"title\" value=\""+menuitem.title+"\" disabled>";
var inputPirce ="<input class='textStyle' id=\""+menuitem._id+"price\" value="+menuitem.price+" disabled>";
$('#menu').append(inputId, " ", inputTitle, " ", inputPirce, " ", btnP, "<BR>");


orderBtn(menuitem._id,menuitem.title,menuitem.price)

}); 


});
function orderBtn(id,title,price)
{
var btnAdd = document.getElementById(id+"add");
btnAdd.addEventListener("click", function(e){
e.preventDefault();
var btnQ = "<button class='btnStyle' id=\""+counter+"remove\">-</button>";
var inputOrder="<input class='textStyle' id=\""+counter+"order\" value=\""+title+"\" name=\"items\">";
//var itemId = document.getElementById(id).value;
//var itemTitle = document.getElementById(id+"title").value;
//var itemPrice = document.getElementById(id+"price").value;
$('#orderitems').append("<tr id="+counter+"D"+"><td>"+inputOrder+"</td><td>"+btnQ+"</td></tr>");
//document.getElementById("orderitems").innerHTML += (inputOrder, btnQ);
deleteBtn(counter);
counter++;
});
}
function deleteBtn(id)
{
var btnDelete = document.getElementById(id+"remove")
console.log(btnDelete);
btnDelete.addEventListener("click", function(){
$("#"+id+"D").remove()
});
}
$( "#enter" ).click(function(){ 
addorder();
})
function addorder() {
var items = document.getElementsByName("items");
var tableNo=0;
var ts = Math.round((new Date()).getTime() / 1000);
console.log(orderNo);
$.each(items, function(index){
var item = items[index].value

$.getJSON('http://localhost:3000/menu/'+item, function(data) {
j++
$.post("http://localhost:3000/addBill",
{
orderId: orderNo,
tableId: tableNo,
title: data.title,
price: data.price,
isPayed: false,
date: ts
},
function(data,status){
}); 

if(data._id>=200)
{
   $.post("http://localhost:3000/addOrder",
{
_id:j,
orderId: orderNo,
tableId: tableNo,
title: data.title,
date: ts
},
function(data,status){
}); 
}
else if(data._id<200)
{
$.post("http://localhost:3000/addDrink",
{
_id:j,
orderId: orderNo,
tableId: tableNo,
title: data.title,
date: ts
},
function(data,status){
}); 
}
else
{
alert("Error")
}


});


});
alert("Order placed.");
location.reload();

}



});