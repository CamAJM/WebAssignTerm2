var mongoose = require('mongoose');
var Schema = mongoose.Schema; 
var tableItemSchema = new Schema({
	_id: Number,
	orderId: Number
});

module.exports = mongoose.model('ActiveTable', tableItemSchema); 
// Finds the collection menuitem. Mongo adds an s to the collection name here. So while "menuitem" is entered, Mongo looks for "menuitems".
